/* 
Programa: 
Autor: Ivan Paiva
Data da Cria��: 20/05/2022
Data de Modifica��o: 20/05/2022
*/
#include<stdio.h>
main()
{
	int i,n1,n2,n3,cont;
	printf("Digite a quantidade de termos:");
	scanf("%d",&i);
	n1 = 1;
	n2 = 1;
	cont = 2;
	printf("%d\n",n1);
	printf("%d\n",n2);
	while( cont < i )
	{
		n3= n1+n2;
		printf("%d\n",n3);
		n1 = n2;
		n2 = n3;
		cont = cont+1;
	}
}
