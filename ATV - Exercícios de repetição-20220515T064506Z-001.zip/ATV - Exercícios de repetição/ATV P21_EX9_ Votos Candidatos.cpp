/*
Programa: Numa elei��o existem tr�s candidatos. Fa�a um programa que pe�a o n�mero
total de eleitores. Pe�a para cada eleitor votar e ao final mostrar o n�mero de
votos de cada candidato.
Autor: Ivan Paiva
Data da Cria��: 13/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main(){
int eleitores,candidato,candidato1=0,candidato2=0,candidato3=0,cont=1;
printf("Informe o total de eleitores da zona ");
scanf("%d",&eleitores);
while (cont<=eleitores)
{
	printf("\nPor favor, informe o seu voto\n Digite 1 para o Candidato 1\n Digite 2 para o Candidato 2\n Digite 3 para o Candidato 3\n");
	scanf("%d",&candidato);
	switch (candidato)
	{
		case 1:
		candidato1++;
		cont++;
		break;
		case 2:
		candidato2++;
		cont++;
		break;
		case 3:
		candidato3++;
		cont++;
		break;		
	default:
	printf("Candidato invalido");	
	}

}
printf ("O total de votos do Candidato 1 eh: %d\n",candidato1);
printf ("O total de votos do Candidato 2 eh: %d\n",candidato2);
printf ("O total de votos do Candidato 3 eh: %d\n",candidato3);
}



