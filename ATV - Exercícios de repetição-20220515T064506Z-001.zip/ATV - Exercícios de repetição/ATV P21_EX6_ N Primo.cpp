/* 
Programa: Fa�a um programa que pe�a um n�mero inteiro e determine se ele � ou n�o um n�mero primo
Autor: Ivan Paiva
Data da Cria��: 13/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main()
{
	int i,div,x=0;
	printf("Digite o numero que sera verificado:\n");
	scanf("%d",&i);
	div=2;
	while (i>div)
	{
		if (i%div==0)
		{
		x=1;
		break;
		}
		else
		{
		div++;
		}
		
}
if (x==1)
	{
	printf("\nO numero nao eh primo\n");
}
	else{
	printf("\nO numero eh primo\n");
}
}
