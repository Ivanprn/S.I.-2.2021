/*
Programa: Fa�a um programa que mostre todos os primos entre 1 e N sendo N um
n�mero inteiro fornecido pelo usu�rio. O programa dever� mostrar tamb�m o
n�mero de divis�es que ele executou para encontrar os n�meros primos. Ser�o
avaliados o funcionamento, o estilo e o n�mero de testes (divis�es)
executados
Autor: Ivan Paiva
Data da Cria��: 13/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
	
	int primo(int n){
	int i,div=0;
		for (i=1;i<=n;i++)
		{
		if(n%i==0)
		div++;	
		}
		if (div==2)
		return 1;
		else
		return 0;
}
	
main()
{
	int i,n,cont=0;
	printf("Digite ate qual numero devera ser verificado ");
	scanf("%d",&n);
	for (i=1;i<=n;i++){
	
	if(primo(i)==1){
	printf("%d ",i);
	cont++;
}
}

printf("\nA quantidade de primos foi %d ",cont);
}
