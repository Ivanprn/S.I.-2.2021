/*
Programa:O Sr. Manoel Joaquim acaba de adquirir uma panificadora e pretende implantar
a metodologia da tabelinha, que j� � um sucesso na sua loja de 1,99. Voc� foi
contratado para desenvolver o programa que monta a tabela de pre�os de
p�es, de 1 at� 50 p�es, a partir do pre�o do p�o informado pelo usu�rio,
conforme o exemplo abaixo:
a) Pre�o do p�o: R$ 0.18
b) Panificadora P�o de Ontem - Tabela de pre�os
c) 1 - R$ 0.18
d) 2 - R$ 0.36
e) ...
f) 50 - R$ 9.00
Autor: Ivan Paiva
Data da Cria��: 14/05/2022
Data de Modifica��o: 14/05/2022
*/
#include<stdio.h>
#include <locale.h>
main()
{
setlocale(LC_ALL,"portuguese");
int i;
float Ppao;
float paes[51];
printf("Informe o valor do p�o R$");
scanf("%f",&Ppao);
for (i=1;i<51;i++){
	paes[i]=Ppao*(i);
}
printf ("\nO Pre�o do p�o: %.2f",Ppao);
printf ("\nPanificadora P�o de Ontem - Tabela de pre�os\n");
for (i=1;i<51;i++){
printf ("\n%d - R$ %.2f\n",i,paes[i]);
}

}
