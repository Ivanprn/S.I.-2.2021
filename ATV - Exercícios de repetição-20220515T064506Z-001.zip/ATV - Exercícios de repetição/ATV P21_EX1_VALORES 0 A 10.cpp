/* 
Programa: Fa�a um programa que pe�a uma nota, entre zero e dez. Mostre uma
mensagem caso o valor seja inv�lido e continue pedindo at� que o usu�rio
informe um valor v�lido.
Autor: Ivan Paiva
Data da Cria��: 12/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main()
{
	int i;
	printf("Informe uma nota de 0 a 10\n");
	scanf("%d",&i);
	while (i<0 || i>10)
	{
		printf("\nNota invalida. Por favor, insira um valor valido\n");
		scanf("%d",&i);
	}
printf("\nFIM\n");
}
