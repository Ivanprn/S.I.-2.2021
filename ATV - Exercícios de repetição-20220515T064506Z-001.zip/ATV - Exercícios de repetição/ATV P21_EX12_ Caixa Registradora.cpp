/*
Programa:
O programa dever� receber um
n�mero desconhecido de valores referentes aos pre�os das mercadorias. Um
valor zero deve ser informado pelo operador para indicar o final da compra. O
programa deve ent�o mostrar o total da compra e perguntar o valor em dinheiro
que o cliente forneceu, para ent�o calcular e mostrar o valor do troco. Ap�s
esta opera��o, o programa dever� voltar ao ponto inicial, para registrar a
pr�xima compra.
A sa�da deve ser conforme o exemplo abaixo:
a) Lojas Tabajara
b) Produto 1: R$ 2.20
c) Produto 2: R$ 5.80
d) Produto 3: R$ 0
e) Total: R$ 9.00
f) Dinheiro: R$ 20.00
g) Troco: R$ 11.00
h) ...
Autor: Ivan Paiva
Data da Cria��: 14/05/2022
Data de Modifica��o: 14/05/2022
*/
#include<stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
setlocale(LC_ALL,"portuguese");
int i,loop=1; 
float mercadorias[3],vmercadoria=1,vtotal=0,vpago;
while (loop==1){
for (i=0; i<3 ; i++){
	printf("\nInforme o valor do %d produto: R$",i+1);
	scanf("%f",&vmercadoria);
	if (vmercadoria!=0){
	mercadorias[i]=vmercadoria;
	vtotal=vtotal+vmercadoria;
	}
}
printf("\n\tLojas Tabajaras\n\t");
for (i=0; i<3 ; i++){
	printf ("\nProduto %d: R$%.2f\n",i+1,mercadorias[i]);
	}
printf ("\nTotal: R$ %.2f\n",vtotal);
printf ("Informe o valor pago pelo cliente: R$");
scanf ("%f",&vpago);
printf ("\nTroco: R$ %.2f\n\n",vpago-vtotal);
vtotal=0;
system("pause");
system("clear||cls");
}

return 0;
}



