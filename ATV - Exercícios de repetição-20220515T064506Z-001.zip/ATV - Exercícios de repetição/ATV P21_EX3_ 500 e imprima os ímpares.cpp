/* 
Programa: Fa�a um programa que imprima na tela apenas os n�meros �mpares entre 1 e 500
Autor: Ivan Paiva
Data da Cria��: 12/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main()
{
	int i;
	for (i=0;i<=500;i++)	
	{
		if (i%2!=0)
		{
		printf("%d\n",i);
	    }
	}
printf("\nFIM\n");
}
