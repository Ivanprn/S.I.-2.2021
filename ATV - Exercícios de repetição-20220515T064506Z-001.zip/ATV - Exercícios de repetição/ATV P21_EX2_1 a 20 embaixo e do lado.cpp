/* 
Programa: Fa�a um programa que imprima na tela os n�meros de 1 a 20, um abaixodo
outro. Depois modifique o programa para que ele mostre os n�meros um ao
lado do outro.

Autor: Ivan Paiva
Data da Cria��: 12/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main()
{
	int i;
	while (i<20)
	{
		i++;
		printf("%d\n",i);
	}
	//para os n�meros serem exibidos um ao lado do outro, basta tirar o \n da sintaxe acima.
printf("\nFIM\n");
}
