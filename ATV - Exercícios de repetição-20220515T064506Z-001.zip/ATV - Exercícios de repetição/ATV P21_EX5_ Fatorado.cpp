/* 
Programa: Fa�a um programa que calcule o fatorial de um n�mero inteiro fornecido pelo
usu�rio
Autor: Ivan Paiva
Data da Cria��: 12/05/2022
Data de Modifica��o: 12/05/2022
*/
#include<stdio.h>
main()
{
	int i,n1,total;
	printf("Digite o numero que sera fatorado:\n");
	scanf("%d",&i);
	total=1;
	for (n1=1; n1<=i;n1++)
	{
		total*=n1;
	}
	printf("%d\n",total);
}
