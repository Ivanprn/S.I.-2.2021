/*
Programa: Fa�a um programa que calcule o n�mero m�dio de alunos por turma Para isto,
pe�a a quantidade de turmas e a quantidade de alunos para cada turma. As
turmas n�o podem ter mais de 40 alunos.
Autor: Ivan Paiva
Data da Cria��: 14/05/2022
Data de Modifica��o: 14/05/2022
*/
#include<stdio.h>
#include <locale.h>
main()
{
setlocale(LC_ALL,"portuguese");
int i,alunos,nturmas,totalalunos=0;
float media;
printf("Por favor, informe o n�mero de turmas: ");
scanf("%d",&nturmas);
int turmas[nturmas];
	for (i=0;i<nturmas;i++){
	printf("\nPor favor, informe o n�mero de alunos.\n");
	scanf("%d",&alunos);
		if (alunos>40){
			printf("\nLimite m�ximo de aluno por turma � de 40 alunos.\n.");
			i--;
			}
		else{
	turmas[i]=alunos;
	totalalunos=totalalunos+alunos;		
	}}
media=totalalunos/nturmas;
printf ("A media de alunos por turma �: %2.f",media);
printf("\nAs turmas por aluno s�o:");
for (i=0;i<nturmas;i++){
printf("\nTurma %d com %d alunos",i+1,turmas[i]);
}
}
