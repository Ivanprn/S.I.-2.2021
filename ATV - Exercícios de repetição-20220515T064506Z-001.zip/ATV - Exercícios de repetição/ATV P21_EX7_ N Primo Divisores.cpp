/*
Programa: Altere o programa de c�lculo dos n�meros primos, informando, caso o n�mero
n�o seja primo, por quais n�mero ele � divis�vel
Autor: Ivan Paiva
Data da Cria��: 13/05/2022
Data de Modifica��o: 13/05/2022
*/
#include<stdio.h>
main()
{
	int i,div,x=0;
	printf("Digite o numero que sera verificado:\n");
	scanf("%d",&i);
	div=2;
	while (i>div)
	{
		if (i%div==0)
		{
		x=1;
		printf("%d ",div);
		//break;
		div++;
		}
		else
		{
		div++;
		}
		
}
if (x==1)
	{
	printf("\nO numero nao eh primo\n");
}
	else{
	printf("\nO numero eh primo\n");
}
}
